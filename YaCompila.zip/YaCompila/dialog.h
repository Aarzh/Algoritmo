#ifndef DIALOG_H
#define DIALOG_H

#include <QDialog>
#include "poligonos.h"
#include "arcos.h"
#include "cubo.h"
#include "prismarec.h"
#include "prismatri.h"
#include "cono.h"

namespace Ui {
class Dialog;
}

class Dialog : public QDialog
{
    Q_OBJECT

public:
    explicit Dialog(QWidget *parent = 0);
    ~Dialog();

private slots:
    void on_BotPoli_clicked();

    void on_BotArcos_clicked();

    void on_BotCubo_clicked();

    void on_BotPrisR_clicked();

    void on_BotPrisT_clicked();

    void on_BotCono_clicked();

private:
    Ui::Dialog *ui;
    //permite multiples ventanas de poligonos
    //Poligonos *poligonos;

};

#endif // DIALOG_H
