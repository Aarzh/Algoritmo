# Instrucciones de uso:
Para poder utilizar este repositorio se tiene que bajar toda la carpeta con los códigos como zip, descomprimirla y abrir el ejecutable llamado "GeometriaComputacional" haciendo doble click en el.
A continuación aparecerá una ventana nueva donde se podrá escoger la figura que se quiera dibujar y transformar, tan solo se tiene
que hacer click en la figura deseada. Después de esto se abrirá una nueva ventana con opciones para dibujar y transformar la figura
seleccionada.

1. Polígonos
  - Indicar el número de lados del polígono que se desea dibujar y hacer click en el botón de dibujar.
  - Si se desea hacer una traslación, se debe indicar la posición en 'x', la posición en 'y' y hacer click en el botón de trasladar.
  - Si se desea hacer una rotación, se deben indicar los grados que se va a rotar la figura y hacer click en rotar.
  - Para realizar zoom in, zoom out, reflexión horizontal o reflexión vertical, se debe de hacer click en su botón corresponiente.

2. Arcos
  - Indicar el radio y el ángulo del arco que se desea dibujar y hacer click en el botón de dibujar.
  - Si se desea hacer una traslación, se debe indicar la posición en 'x', la posición en 'y' y hacer click en el botón de trasladar.
  - Si se desea hacer una rotación, se deben indicar los grados que se va a rotar la figura y hacer click en rotar.
  - Para realizar zoom in, zoom out, reflexión horizontal o reflexión vertical, se debe de hacer click en su botón corresponiente.
  
3. Cubo, Prisma Rectangular, Prisma Triangular y Cono
  - Hacer click en el botón de dibujar solamente.
  - Si se desea hacer una traslación, se debe indicar la posición en 'x', la posición en 'y' y hacer click en el botón de trasladar.
  - Si se desea hacer una rotación, se deben indicar los grados que se va a rotar la figura y hacer click en rotar.
  - Para realizar zoom in, zoom out, reflexión horizontal o reflexión vertical, se debe de hacer click en su botón corresponiente.
